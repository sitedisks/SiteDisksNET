﻿playlistModule.controller('PlaylistCtrl', function ($scope, $stateParams) {
    $scope.message = $stateParams.playlistId;

    $scope.code = "009";
});