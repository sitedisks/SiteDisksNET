﻿var loginModule = angular.module('login', []);
var playlistModule = angular.module('playlist', []);
var dashboardModule = angular.module('dashboard', []);
